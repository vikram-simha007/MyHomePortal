﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Trirand.Web.Mvc;
namespace JQueryGridSample.Models
{
    public class EmployeeJQGridModel
    {
        public JQGrid EmployeeGrid;
        public EmployeeJQGridModel()
        {
            EmployeeGrid = new JQGrid
            {
                Columns = new List<JQGridColumn>()
                {
                    new JQGridColumn { DataField = "EmployeeID", PrimaryKey = true }, 
                    new JQGridColumn { DataField = "LastName" }, 
                    new JQGridColumn { DataField = "FirstName" }, 
                    new JQGridColumn { DataField = "Title" } 
               
                }
            };
        }
    }
    public class GenericEmployeeRepository : EmployeeRepository { }
}