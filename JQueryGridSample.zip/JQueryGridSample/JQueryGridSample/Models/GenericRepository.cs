﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using JQueryGridSample.Models;
using System.Data.Entity;
using System.Data.Entity.Migrations;

namespace JQueryGridSample.Models
{
    public abstract class EmployeeRepository
    {
       
        DbContext dataContext;
        List<Employee> employees;
        public EmployeeRepository()
        {
            employees = new List<Employee>();
            employees.Add(new Employee { EmployeeID = 1, FirstName = "vik", LastName = "", Title = "" });
            employees.Add(new Employee { EmployeeID = 2, FirstName = "vik", LastName = "", Title = "" });
            employees.Add(new Employee { EmployeeID = 3, FirstName = "vik", LastName = "", Title = "" });
            employees.Add(new Employee { EmployeeID = 4, FirstName = "vik", LastName = "", Title = "" });
            employees.Add(new Employee { EmployeeID = 5, FirstName = "vik", LastName = "", Title = "" });
            employees.Add(new Employee { EmployeeID = 6, FirstName = "vik", LastName = "", Title = "" });
            employees.Add(new Employee { EmployeeID = 7, FirstName = "vik", LastName = "", Title = "" });
            employees.Add(new Employee { EmployeeID = 8, FirstName = "vik", LastName = "", Title = "" });
            employees.Add(new Employee { EmployeeID = 9, FirstName = "vik", LastName = "", Title = "" });
            employees.Add(new Employee { EmployeeID = 10, FirstName = "vik", LastName = "", Title = "" });
        }

       

        //================================================================
        //================================================================

        #region IRepository<T> Members



        public IEnumerable<Employee> GetAll()
        {
            return employees;
        }

     
        #endregion
    }
}
